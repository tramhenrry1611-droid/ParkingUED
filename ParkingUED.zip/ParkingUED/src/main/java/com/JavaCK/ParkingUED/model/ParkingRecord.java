package com.JavaCK.ParkingUED.model;

import java.sql.Timestamp;
import java.time.LocalDateTime;

public class ParkingRecord {
    private int recordId;
    private int vehicleId;
    private Integer slotId;
    private LocalDateTime timeIn;
    private LocalDateTime timeOut;
    private double fee;
    private String sessionType;
    private Timestamp createdAt;

    public ParkingRecord() {}

    public int getRecordId() { return recordId; }
    public void setRecordId(int recordId) { this.recordId = recordId; }

    public int getVehicleId() { return vehicleId; }
    public void setVehicleId(int vehicleId) { this.vehicleId = vehicleId; }

    public Integer getSlotId() { return slotId; }
    public void setSlotId(Integer slotId) { this.slotId = slotId; }

    public LocalDateTime getTimeIn() { return timeIn; }
    public void setTimeIn(LocalDateTime timeIn) { this.timeIn = timeIn; }

    public LocalDateTime getTimeOut() { return timeOut; }
    public void setTimeOut(LocalDateTime timeOut) { this.timeOut = timeOut; }

    public double getFee() { return fee; }
    public void setFee(double fee) { this.fee = fee; }

    public String getSessionType() { return sessionType; }
    public void setSessionType(String sessionType) { this.sessionType = sessionType; }

    public Timestamp getCreatedAt() { return createdAt; }
    public void setCreatedAt(Timestamp createdAt) { this.createdAt = createdAt; }
}
