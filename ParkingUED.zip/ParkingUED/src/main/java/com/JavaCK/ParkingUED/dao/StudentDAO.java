package com.JavaCK.ParkingUED.dao;

import com.JavaCK.ParkingUED.model.Student;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class StudentDAO {

    // Insert student, returns generated student_id or -1 on fail
    public int insert(Student s) {
        String sql = "INSERT INTO Student(student_code, name, faculty, phone) VALUES (?,?,?,?)";
        try (Connection conn = DBConnector.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, s.getStudentCode());
            ps.setString(2, s.getName());
            ps.setString(3, s.getFaculty());
            ps.setString(4, s.getPhone());

            int affected = ps.executeUpdate();
            if (affected == 0) return -1;
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) return keys.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }

    public Student findById(int id) {
        String sql = "SELECT * FROM Student WHERE student_id = ?";
        try (Connection conn = DBConnector.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public Student findByCode(String code) {
        String sql = "SELECT * FROM Student WHERE student_code = ?";
        try (Connection conn = DBConnector.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, code);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<Student> findAll() {
        List<Student> list = new ArrayList<>();
        String sql = "SELECT * FROM Student ORDER BY student_id DESC";
        try (Connection conn = DBConnector.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public boolean update(Student s) {
        String sql = "UPDATE Student SET student_code = ?, name = ?, faculty = ?, phone = ? WHERE student_id = ?";
        try (Connection conn = DBConnector.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, s.getStudentCode());
            ps.setString(2, s.getName());
            ps.setString(3, s.getFaculty());
            ps.setString(4, s.getPhone());
            ps.setInt(5, s.getStudentId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean delete(int studentId) {
        String sql = "DELETE FROM Student WHERE student_id = ?";
        try (Connection conn = DBConnector.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, studentId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    private Student mapRow(ResultSet rs) throws SQLException {
        // make sure Student class has matching constructor/getters
        Student s = new Student();
        s.setStudentId(rs.getInt("student_id"));
        s.setStudentCode(rs.getString("student_code"));
        s.setName(rs.getString("name"));
        s.setFaculty(rs.getString("faculty"));
        s.setPhone(rs.getString("phone"));
        Timestamp ts = rs.getTimestamp("created_at");
        s.setCreatedAt(ts); // Student class must have setCreatedAt(Timestamp)
        return s;
    }
}
