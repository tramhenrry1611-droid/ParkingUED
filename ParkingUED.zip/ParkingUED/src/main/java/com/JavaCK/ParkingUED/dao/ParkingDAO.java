package com.JavaCK.ParkingUED.dao;

import java.sql.*;
import java.time.Duration;
import java.time.LocalDateTime;

import com.JavaCK.ParkingUED.model.ParkingRecord;

public class ParkingDAO {

    // ------------------- CHECK IN -------------------
    public boolean checkIn(int vehicleId, String slotCode, String sessionType) {
        String findSlot = "SELECT slot_id FROM ParkingSlot WHERE code = ?";
        String insertRecord = """
            INSERT INTO ParkingRecord(vehicle_id, slot_id, time_in, session_type)
            VALUES (?, ?, NOW(), ?)
        """;

        try (Connection con = DBConnector.getConnection();
             PreparedStatement psSlot = con.prepareStatement(findSlot);
             PreparedStatement psInsert = con.prepareStatement(insertRecord)) {

            // tìm slot_id theo code
            psSlot.setString(1, slotCode);
            ResultSet rs = psSlot.executeQuery();
            if (!rs.next()) return false;

            int slotId = rs.getInt("slot_id");

            // insert record
            psInsert.setInt(1, vehicleId);
            psInsert.setInt(2, slotId);
            psInsert.setString(3, sessionType);

            return psInsert.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }


    // ------------------- CHECK OUT -------------------
    public boolean checkOut(int vehicleId) {

        // 1. Lấy record chưa checkout
        String findRecord = """
            SELECT record_id, time_in, session_type
            FROM ParkingRecord
            WHERE vehicle_id = ? AND time_out IS NULL
            ORDER BY time_in DESC
            LIMIT 1
        """;

        // 2. cập nhật checkout + fee
        String update = """
            UPDATE ParkingRecord
            SET time_out = NOW(), fee = ?
            WHERE record_id = ?
        """;

        try (Connection con = DBConnector.getConnection();
             PreparedStatement psFind = con.prepareStatement(findRecord);
             PreparedStatement psUpdate = con.prepareStatement(update)) {

            psFind.setInt(1, vehicleId);
            ResultSet rs = psFind.executeQuery();

            if (!rs.next()) return false; // chưa check-in

            int recordId = rs.getInt("record_id");
            LocalDateTime timeIn = rs.getTimestamp("time_in").toLocalDateTime();
            String sessionType = rs.getString("session_type");

            // ---- tính phí ----
            double fee = calculateFee(timeIn, sessionType);

            // cập nhật
            psUpdate.setDouble(1, fee);
            psUpdate.setInt(2, recordId);

            return psUpdate.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    // ------------------- TÍNH PHÍ -------------------
    private double calculateFee(LocalDateTime timeIn, String sessionType) {
        switch (sessionType.toLowerCase()) {
            case "buổi sáng": return 3000;
            case "buổi chiều": return 3000;
            case "buổi tối": return 5000;
            case "theo_gio":
                long hours = Duration.between(timeIn, LocalDateTime.now()).toHours();
                if (hours == 0) hours = 1;
                return hours * 2000;
            default:
                return 4000; // default
        }
    }
    
}
