package com.JavaCK.ParkingUED.controller;

import java.time.LocalDate;
import java.util.List;

import com.JavaCK.ParkingUED.dao.ParkingDAO;
import com.JavaCK.ParkingUED.dao.StatisticDAO;
import com.JavaCK.ParkingUED.dao.StudentDAO;
import com.JavaCK.ParkingUED.dao.VehicleDAO;
import com.JavaCK.ParkingUED.model.ParkingRecord;
import com.JavaCK.ParkingUED.model.Student;
import com.JavaCK.ParkingUED.model.Vehicle;

/**
 * Controller trung gian giữa View và DAO.
 * Lưu ý: phương thức insert() của DAO được giả định trả về int (generated id) như trong StudentDAO/VehicleDAO
 */
public class ParkingController {

    private final StudentDAO studentDAO;
    private final VehicleDAO vehicleDAO;
    private final ParkingDAO parkingDAO;
    private final StatisticDAO statisticDAO;

    public ParkingController() {
        this.studentDAO = new StudentDAO();
        this.vehicleDAO = new VehicleDAO();
        this.parkingDAO = new ParkingDAO();
        this.statisticDAO = new StatisticDAO();
    }

    // ---------------- STUDENT ----------------

    /** Thêm student. Trả về true nếu thêm thành công. */
    public boolean addStudent(Student s) {
        // StudentDAO.insert(...) trả về generated id (int) theo implementation đã cung cấp.
        int id = studentDAO.insert(s);
        return id > 0;
    }

    public Student findStudentByCode(String code) {
        return studentDAO.findByCode(code);
    }

    // ---------------- VEHICLE ----------------

    /** Thêm vehicle. Trả về true nếu insert thành công (generated id > 0) */
    public boolean addVehicle(Vehicle v) {
        // nếu VehicleDAO.insert trả boolean thay vì int, sửa DAO hoặc đổi lại ở đây.
        int newId = vehicleDAO.insert(v); // giả định insert trả int
        return newId > 0;
    }

    public Vehicle findVehicleByPlate(String plate) {
        return vehicleDAO.findByPlate(plate);
    }

    public List<Vehicle> findVehiclesByStudent(int studentId) {
        return vehicleDAO.getByStudentId(studentId);
    }

    // ---------------- PARKING ----------------

    /** Check-in: trả về true nếu insert record thành công */
    public boolean checkIn(int vehicleId, String slotCode, String sessionType) {
        return parkingDAO.checkIn(vehicleId, slotCode, sessionType);
    }

    /** Check-out: thực hiện tính phí & cập nhật time_out, trả về true nếu thành công */
    public boolean checkOut(int vehicleId) {
        return parkingDAO.checkOut(vehicleId);
    }

    // ---------------- STATISTICS ----------------

    public int getTotalVehiclesToday() {
        return statisticDAO.getTotalVehiclesToday();
    }

    public List<ParkingRecord> getActiveParkingRecords() {
        return statisticDAO.getActiveParkingRecords();
    }

    public double getDailyRevenue(LocalDate date) {
        return statisticDAO.getDailyRevenue(date);
    }
}
