package com.JavaCK.ParkingUED.dao;

import com.JavaCK.ParkingUED.model.ParkingRecord;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class ParkingRecordDAO {

    // Insert a new check-in record (time_in = NOW). Returns generated record_id or -1.
    public int checkIn(int vehicleId, Integer slotId, String sessionType) {
        String sql = "INSERT INTO ParkingRecord (vehicle_id, slot_id, time_in, session_type) VALUES (?, ?, NOW(), ?)";
        try (Connection conn = DBConnector.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setInt(1, vehicleId);
            if (slotId == null) ps.setNull(2, Types.INTEGER);
            else ps.setInt(2, slotId);
            ps.setString(3, sessionType);

            int affected = ps.executeUpdate();
            if (affected == 0) return -1;
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) return keys.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }

    // Check-out: set time_out = NOW(), update fee. Returns true if a row updated.
    public boolean checkOut(int recordId, double fee) {
        String sql = "UPDATE ParkingRecord SET time_out = NOW(), fee = ? WHERE record_id = ? AND time_out IS NULL";
        try (Connection conn = DBConnector.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setDouble(1, fee);
            ps.setInt(2, recordId);
            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Find active (not checked-out) record for a vehicle
    public ParkingRecord findActiveByVehicleId(int vehicleId) {
        String sql = "SELECT * FROM ParkingRecord WHERE vehicle_id = ? AND time_out IS NULL ORDER BY time_in DESC LIMIT 1";
        try (Connection conn = DBConnector.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, vehicleId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return null;
    }

    // Find all records for a vehicle
    public List<ParkingRecord> findByVehicleId(int vehicleId) {
        List<ParkingRecord> list = new ArrayList<>();
        String sql = "SELECT * FROM ParkingRecord WHERE vehicle_id = ? ORDER BY time_in DESC";
        try (Connection conn = DBConnector.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, vehicleId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapRow(rs));
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    // Find all records by student_code (join Vehicle + Student)
    public List<ParkingRecord> findByStudentCode(String studentCode) {
        List<ParkingRecord> list = new ArrayList<>();
        String sql = "SELECT pr.* FROM ParkingRecord pr " +
                     "JOIN Vehicle v ON pr.vehicle_id = v.vehicle_id " +
                     "JOIN Student s ON v.owner_student_id = s.student_id " +
                     "WHERE s.student_code = ? ORDER BY pr.time_in DESC";
        try (Connection conn = DBConnector.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, studentCode);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapRow(rs));
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    // Count visits per vehicle for a given student_code
    public List<VisitCount> countVisitsByStudent(String studentCode) {
        List<VisitCount> out = new ArrayList<>();
        String sql = "SELECT v.plate, COUNT(pr.record_id) AS visits " +
                     "FROM ParkingRecord pr JOIN Vehicle v ON pr.vehicle_id = v.vehicle_id " +
                     "JOIN Student s ON v.owner_student_id = s.student_id " +
                     "WHERE s.student_code = ? GROUP BY v.vehicle_id, v.plate";
        try (Connection conn = DBConnector.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, studentCode);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    out.add(new VisitCount(rs.getString("plate"), rs.getInt("visits")));
                }
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return out;
    }

    // Map a ResultSet row to ParkingRecord
    private ParkingRecord mapRow(ResultSet rs) throws SQLException {
        ParkingRecord pr = new ParkingRecord();
        pr.setRecordId(rs.getInt("record_id"));
        pr.setVehicleId(rs.getInt("vehicle_id"));
        int slot = rs.getInt("slot_id");
        if (rs.wasNull()) pr.setSlotId(null);
        else pr.setSlotId(slot);
        Timestamp tin = rs.getTimestamp("time_in");
        if (tin != null) pr.setTimeIn(tin.toLocalDateTime());
        Timestamp tout = rs.getTimestamp("time_out");
        if (tout != null) pr.setTimeOut(tout.toLocalDateTime());
        pr.setFee(rs.getDouble("fee"));
        pr.setSessionType(rs.getString("session_type"));
        pr.setCreatedAt(rs.getTimestamp("created_at"));
        return pr;
    }

    // Helper DTO for counting visits
    public static class VisitCount {
        private final String plate;
        private final int visits;
        public VisitCount(String plate, int visits) { this.plate = plate; this.visits = visits; }
        public String getPlate() { return plate; }
        public int getVisits() { return visits; }
    }
}
