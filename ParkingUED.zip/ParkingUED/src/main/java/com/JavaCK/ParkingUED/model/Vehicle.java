package com.JavaCK.ParkingUED.model;

public class Vehicle {
    private int vehicleId;
    private String plate;
    private String type;
    private int ownerStudentId;

    public Vehicle() {}

    public int getVehicleId() { return vehicleId; }
    public void setVehicleId(int vehicleId) { this.vehicleId = vehicleId; }

    public String getPlate() { return plate; }
    public void setPlate(String plate) { this.plate = plate; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public int getOwnerStudentId() { return ownerStudentId; }
    public void setOwnerStudentId(int ownerStudentId) { this.ownerStudentId = ownerStudentId; }
}
