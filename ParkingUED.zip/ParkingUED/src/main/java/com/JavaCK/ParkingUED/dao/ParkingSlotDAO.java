package com.JavaCK.ParkingUED.dao;

import com.JavaCK.ParkingUED.model.ParkingSlot;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ParkingSlotDAO {

    public int insert(ParkingSlot slot) {
        String sql = "INSERT INTO ParkingSlot(code, area, is_active) VALUES (?, ?, ?)";
        try (Connection conn = DBConnector.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, slot.getCode());
            ps.setString(2, slot.getArea());
            ps.setBoolean(3, slot.isActive());

            int affected = ps.executeUpdate();
            if (affected == 0) return -1;
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) return keys.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }

    public ParkingSlot findById(int id) {
        String sql = "SELECT * FROM ParkingSlot WHERE slot_id = ?";
        try (Connection conn = DBConnector.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public ParkingSlot findByCode(String code) {
        String sql = "SELECT * FROM ParkingSlot WHERE code = ?";
        try (Connection conn = DBConnector.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, code);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<ParkingSlot> findAll() {
        List<ParkingSlot> list = new ArrayList<>();
        String sql = "SELECT * FROM ParkingSlot ORDER BY slot_id";
        try (Connection conn = DBConnector.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public boolean update(ParkingSlot slot) {
        String sql = "UPDATE ParkingSlot SET code = ?, area = ?, is_active = ? WHERE slot_id = ?";
        try (Connection conn = DBConnector.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, slot.getCode());
            ps.setString(2, slot.getArea());
            ps.setBoolean(3, slot.isActive());
            ps.setInt(4, slot.getSlotId());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean delete(int slotId) {
        String sql = "DELETE FROM ParkingSlot WHERE slot_id = ?";
        try (Connection conn = DBConnector.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, slotId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    private ParkingSlot mapRow(ResultSet rs) throws SQLException {
        ParkingSlot p = new ParkingSlot();
        p.setSlotId(rs.getInt("slot_id"));
        p.setCode(rs.getString("code"));
        p.setArea(rs.getString("area"));
        p.setActive(rs.getBoolean("is_active"));
        return p;
    }
}
