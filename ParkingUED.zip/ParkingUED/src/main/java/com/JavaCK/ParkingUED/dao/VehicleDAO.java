package com.JavaCK.ParkingUED.dao;

import com.JavaCK.ParkingUED.model.Vehicle;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class VehicleDAO {

    public int insert(Vehicle v) {
        String sql = "INSERT INTO Vehicle(plate, type, owner_student_id) VALUES (?, ?, ?)";
        try (Connection con = DBConnector.getConnection();
             PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, v.getPlate());
            ps.setString(2, v.getType());
            ps.setInt(3, v.getOwnerStudentId());

            int affected = ps.executeUpdate();
            if (affected == 0) return -1;
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) return rs.getInt(1);
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return -1;
    }

    public boolean exists(String plate) {
        String sql = "SELECT 1 FROM Vehicle WHERE plate = ?";
        try (Connection con = DBConnector.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, plate);
            try (ResultSet rs = ps.executeQuery()) { return rs.next(); }
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    public Vehicle findByPlate(String plate) {
        String sql = "SELECT vehicle_id, plate, type, owner_student_id FROM Vehicle WHERE plate = ?";
        try (Connection con = DBConnector.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, plate);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return null;
    }

    public List<Vehicle> getByStudentId(int studentId) {
        List<Vehicle> list = new ArrayList<>();
        String sql = "SELECT vehicle_id, plate, type, owner_student_id FROM Vehicle WHERE owner_student_id = ?";
        try (Connection con = DBConnector.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, studentId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapRow(rs));
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    private Vehicle mapRow(ResultSet rs) throws SQLException {
        Vehicle v = new Vehicle();
        v.setVehicleId(rs.getInt("vehicle_id"));
        v.setPlate(rs.getString("plate"));
        v.setType(rs.getString("type"));
        v.setOwnerStudentId(rs.getInt("owner_student_id"));
        return v;
    }
}
