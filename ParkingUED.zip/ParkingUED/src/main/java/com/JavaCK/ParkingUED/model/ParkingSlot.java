package com.JavaCK.ParkingUED.model;

public class ParkingSlot {
    private int slotId;
    private String code;
    private String area;
    private boolean isActive;

    public ParkingSlot() {}

    public ParkingSlot(int slotId, String code, String area, boolean isActive) {
        this.slotId = slotId;
        this.code = code;
        this.area = area;
        this.isActive = isActive;
    }

    public int getSlotId() { return slotId; }
    public void setSlotId(int slotId) { this.slotId = slotId; }

    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }

    public String getArea() { return area; }
    public void setArea(String area) { this.area = area; }

    public boolean isActive() { return isActive; }
    public void setActive(boolean active) { isActive = active; }

    @Override
    public String toString() {
        return "ParkingSlot{" +
                "slotId=" + slotId +
                ", code='" + code + '\'' +
                ", area='" + area + '\'' +
                ", isActive=" + isActive +
                '}';
    }
}
