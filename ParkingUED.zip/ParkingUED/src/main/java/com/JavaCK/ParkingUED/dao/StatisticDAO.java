package com.JavaCK.ParkingUED.dao;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.JavaCK.ParkingUED.model.ParkingRecord;

public class StatisticDAO {

    // ------------------- TỔNG XE HÔM NAY -------------------
    public int getTotalVehiclesToday() {
        String sql = """
            SELECT COUNT(*) AS total
            FROM ParkingRecord
            WHERE DATE(time_in) = CURDATE()
        """;

        try (Connection con = DBConnector.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getInt("total");

        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }


    // ------------------- XE ĐANG GỬI -------------------
    public List<ParkingRecord> getActiveParkingRecords() {
        List<ParkingRecord> list = new ArrayList<>();

        String sql = """
            SELECT record_id, vehicle_id, slot_id, time_in, session_type
            FROM ParkingRecord
            WHERE time_out IS NULL
            ORDER BY time_in ASC
        """;

        try (Connection con = DBConnector.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                ParkingRecord pr = new ParkingRecord();
                pr.setRecordId(rs.getInt("record_id"));
                pr.setVehicleId(rs.getInt("vehicle_id"));
                pr.setSlotId(rs.getInt("slot_id"));
                pr.setTimeIn(rs.getTimestamp("time_in").toLocalDateTime());
                pr.setSessionType(rs.getString("session_type"));
                list.add(pr);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }


    // ------------------- DOANH THU THEO NGÀY -------------------
    public double getDailyRevenue(LocalDate date) {
        String sql = """
            SELECT SUM(fee) AS total
            FROM ParkingRecord
            WHERE DATE(time_out) = ?
        """;

        try (Connection con = DBConnector.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setDate(1, java.sql.Date.valueOf(date));
            ResultSet rs = ps.executeQuery();

            if (rs.next()) return rs.getDouble("total");

        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0.0;
    }
}
