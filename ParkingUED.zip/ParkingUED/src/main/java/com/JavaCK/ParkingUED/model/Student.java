package com.JavaCK.ParkingUED.model;

import java.sql.Timestamp;

public class Student {
    private int studentId;
    private String studentCode;
    private String name;
    private String faculty;
    private String phone;
    private Timestamp createdAt;

    public Student() {}

    public Student(int studentId, String studentCode, String name, String faculty, String phone, Timestamp createdAt) {
        this.studentId = studentId;
        this.studentCode = studentCode;
        this.name = name;
        this.faculty = faculty;
        this.phone = phone;
        this.createdAt = createdAt;
    }

    // getters + setters
    public int getStudentId() { return studentId; }
    public void setStudentId(int studentId) { this.studentId = studentId; }

    public String getStudentCode() { return studentCode; }
    public void setStudentCode(String studentCode) { this.studentCode = studentCode; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getFaculty() { return faculty; }
    public void setFaculty(String faculty) { this.faculty = faculty; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public Timestamp getCreatedAt() { return createdAt; }
    public void setCreatedAt(Timestamp createdAt) { this.createdAt = createdAt; }

    @Override
    public String toString() {
        return "Student{" +
                "studentId=" + studentId +
                ", studentCode='" + studentCode + '\'' +
                ", name='" + name + '\'' +
                ", faculty='" + faculty + '\'' +
                ", phone='" + phone + '\'' +
                ", createdAt=" + createdAt +
                '}';
    }
}
